$(".exportExcel").click(function(e) {
	// redireciona para outra página
	// window.location.href = "https://www.google.com/";
	// window.location.href = criaLinkExcel();
	console.log(criaLinkExcel());
});

// monta link com dados para criar excel
function criaLinkExcel(){
	// tipo de dado excel	
	var data_type = 'data:application/vnd.ms-excel';
	// obtém o componente da tabela
	var table_div = document.getElementById('dvData');
	// substitui os caracteres space do componente da tabela
	var table_html = table_div.outerHTML.replace(/ /g, '%20');

	return data_type + ", " + table_html;
}