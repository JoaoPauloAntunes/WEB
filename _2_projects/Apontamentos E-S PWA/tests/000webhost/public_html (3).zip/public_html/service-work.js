// cria um nome de cache estático único para o build corrente
// o valor atualizar garante que o cache atualize quando houver alteração
// neste arquivo
let date = (new Date()+"").split(' ');
const staticCacheName  = 'antunes-joao-'+date[2]+"/"+date[1]+"/"+date[3]+" "+date[4];
console.log(staticCacheName);

const filesToCache = [
    '/index.php'
];

// INSTALL
// Cache on install
// instala o cache toda vez que este arquivo é alterado
this.addEventListener("install", event => {
  this.skipWaiting();

  event.waitUntil(
    caches.open(staticCacheName)
      .then(cache => {
        return cache.addAll(filesToCache);
    })
  )
});

// ACTIVATE
/** assim como INSTALL, este é ativado somente uma vez,
 * quando uma nova versão deste arquivo foi instalada e
 * não tem nenhuma versão anterior rodando em outra aba.
 * Então, basicamente, é utilizado para remover coisas
 * antigas de versões anteriores
*/
// 
// Clear cache on activate
this.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames
            // filtra o cache para verificar se ele inicia com 'antunes-joao-'
          .filter(cacheName => (cacheName.startsWith('antunes-joao-')))
            // filtra o cache para verificar se é diferente de staticCacheName
          .filter(cacheName => (cacheName !== staticCacheName))
            // se é diferente, remove caches antigos
          .map(cacheName => caches.delete(cacheName))
      );
    })
  );
});

// FETCH
/** este evento é ativado toda vez que uma página é requisitada
 * verifica se o arquivo requisitado contém no cache. 
 * Se tiver, retorna o arquivo direto do cache.
 * Senão: rediciona usuário para alguma página
*/
// Serve from Cache (servir a partir do cache)
this.addEventListener("fetch", event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        return response || fetch(event.request);
      })
      .catch(() => {
        return caches.match('/index.php');
      })
  )
});
