$(".exportExcel").click(function(e) {
	// cria um componente de tag <a></a> anchor
	var a = document.createElement('a');
	// tipo de dado excel	
	var data_type = 'data:application/vnd.ms-excel';
	// obtém o componente da tabela
	var table_div = document.getElementById('dvData');
	// substitui os caracteres space do componente da tabela
	var table_html = table_div.outerHTML.replace(/ /g, '%20');
	// monta um link pronto para fazer um arquivo excel
	// ex: "data:application/vnd.ms-excel, <table>%20<tr>%20<th>Column%20One</th>%20</tr>%20</table>"
	a.href = data_type + ', ' + table_html;
	a.download = 'filename.xls';
	a.click();
	e.preventDefault();
});